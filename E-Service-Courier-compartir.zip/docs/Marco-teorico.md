# E-Service Courier

## 2.2. Marco teórico

**Estructuras de datos.** Una estructura de datos organiza elementos y permite operar sobre ellos. El aplicativo usa una cola para programar la atención de los pedidos, una pila para consultar operaciones recientes y un árbol ordenado para localizar y actualizar pedidos por identificador.

**Cola FIFO y lista enlazada.** FIFO significa que el primer elemento en entrar es el primero en salir. La clase `ColaPedidos` usa una `LinkedList<Pedido>`, una lista doblemente enlazada que permite operar en ambos extremos. El método `offerLast()` agrega un pedido al final y `pollFirst()` retira el primero. Si se registran los pedidos 001 y 002 en ese orden, el 001 pasa primero a «En tránsito». Cuando la cola queda vacía, la aplicación informa que no hay pedidos pendientes (Oracle, s. f.-a, s. f.-b).

**Pila LIFO.** LIFO significa que el último elemento insertado ocupa la parte superior de la pila. La clase `Historial` usa una `ArrayDeque<Operacion>` y agrega cada operación mediante `push()`. La consulta recorre el historial desde la operación más reciente y conserva los registros en memoria. Por ejemplo, al confirmar la entrega de un pedido, esa acción aparece por encima de su procesamiento y registro (Oracle, s. f.-a).

**Árbol de búsqueda.** Un árbol de búsqueda ordena sus claves para localizar elementos. En el aplicativo, `GestorPedidos` usa `TreeMap<Integer, Pedido>`, una implementación basada en un árbol rojo-negro. La clave es el identificador del pedido. Cuando el operador confirma una entrega, el gestor localiza el pedido por su ID, verifica que esté en tránsito y actualiza su estado. El recorrido en orden de claves permite presentar la tabla ordenada por identificador (Oracle, s. f.-c).

**Java, Swing y Apache NetBeans.** El aplicativo está escrito en Java 21. Swing proporciona la ventana principal, las tablas, los botones y el diálogo de historial. El proyecto tiene una estructura Maven que permite abrirlo en Apache NetBeans. Los pedidos y las operaciones se almacenan en memoria durante la sesión.

## Referencias

Oracle. (s. f.-a). *Deque (Java SE 21 & JDK 21)*. https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/Deque.html

Oracle. (s. f.-b). *LinkedList (Java SE 21 & JDK 21)*. https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/LinkedList.html

Oracle. (s. f.-c). *TreeMap (Java SE 21 & JDK 21)*. https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/TreeMap.html

